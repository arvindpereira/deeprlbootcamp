* Activate the conda environment by running
	```
    source activate deeprlbootcamp
    ```
* Launch IPython Notebook from this directory; this should open up a browser window where you can click to open Lab1 and Lab2
	```
    jupyter notebook
    ```
* After opening a lab file, click “File - Trust Notebook”
* If you have never used IPython Notebook before, skim this quick tutorial here: http://cs231n.github.io/ipython-tutorial/ 